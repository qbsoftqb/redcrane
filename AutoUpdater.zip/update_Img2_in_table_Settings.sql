IF EXISTS(SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'tbl_Settings' AND COLUMN_NAME = 'Img2')

BEGIN

-- column exists, insert data into it

PRINT 'Column exist';

END

ELSE

BEGIN

-- column does not exist, do something else
ALTER TABLE tbl_Settings
	ADD Img2 NVARCHAR(MAX) not null DEFAULT ' '
ALTER TABLE tbl_Settings
	ADD PrinterKitchen NVARCHAR(500) not null DEFAULT ' '
ALTER TABLE tbl_Settings
	ADD PrinterCheckFood NVARCHAR(500) not null DEFAULT ' '
END
go
UPDATE [dbo].[tbl_GoodsCat]
   SET 
      [GoodsCatFather] =0
      
 WHERE GoodsCatID=1
GO
